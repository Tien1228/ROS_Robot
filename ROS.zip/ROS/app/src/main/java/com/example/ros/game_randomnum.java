package com.example.ros;

import java.util.Scanner;

public class game_randomnum {

	public static void main(String[] args) {
		Scanner inp = new Scanner(System.in);
		int num = getrandom(1, 15);
		while (true) {
			for (int i = 1; i <= 3; i++) {
				int guess = inp.nextInt();
				if (i == 2) {
					System.out.println("失敗");
					System.exit(0);
				}
				if (guess > num) {
					System.out.println("數字太大，請往小的猜");
				} else if (guess < num) {
					System.out.println("數字太小，請往大的猜");
				} else {
					System.out.println("成功!!");
					System.exit(0);
				}
				if (i < 3) {
					System.out.println("您還有" + (2 - i) + "次機會~");
				}
			}
		}
	}

	private static int getrandom(int min, int max) {
		return (int) (Math.floor(Math.random() * (max - min + 1)) + min);
	}
}
